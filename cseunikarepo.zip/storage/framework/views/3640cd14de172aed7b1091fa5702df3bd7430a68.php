<?php $__env->startSection('content'); ?>

<div class="row">
    <div class="col-md-8 col-md-offset-2">
        <div class="panel panel-default">
            
              
          
            <div class="panel-heading"><?php echo e($kegiatan->Judul); ?> 
              <?php if($kegiatan->Status == 'HMPSSI'): ?>
                <?php if($peran_id == 10): ?>
                  <a href="/dashboard" class="pull-right btn btn-default btn-xs">Kembali</a>
                <?php else: ?>
                  <a href="/hmpssi" class="pull-right btn btn-default btn-xs">Kembali</a>
                <?php endif; ?> 
              <?php elseif($kegiatan->Status == 'BEM'): ?>
                <?php if($peran_id == 9): ?>
                  <a href="/dashboard" class="pull-right btn btn-default btn-xs">Kembali</a>  
                <?php else: ?>
                  <a href="/bem" class="pull-right btn btn-default btn-xs">Kembali</a>
                <?php endif; ?>
              <?php elseif($kegiatan->Status == 'Senat'): ?>
                <?php if($peran_id == 9): ?>
                  <a href="/dashboard" class="pull-right btn btn-default btn-xs">Kembali</a>
                <?php else: ?>
                  <a href="/senat" class="pull-right btn btn-default btn-xs">Kembali</a>
                <?php endif; ?>  
              <?php elseif($kegiatan->Status == 'HMPTI'): ?>
                <?php if($peran_id == 9): ?>
                  <a href="/dashboard" class="pull-right btn btn-default btn-xs">Kembali</a>
                <?php else: ?>
                  <a href="/hmpti" class="pull-right btn btn-default btn-xs">Kembali</a>
                <?php endif; ?>
              <?php else: ?>
                <a href="/dashboard" class="pull-right btn btn-default btn-xs">Kembali</a>
              <?php endif; ?>
            </div>

            <div class="panel-body">
              <ul class="list-group">
                <?php if($kegiatan->Status == 'HMPSSI'): ?>
                  <li class="list-group-item">Mahasiswa Pengunggah Kegiatan HMPPSI: <br> 
                    Nama: <?php echo e($siswa->nama); ?> <br>
                    NIM: <?php echo e($siswa->nim); ?>

                  </li>
                <?php elseif($kegiatan->Status == 'BEM'): ?>
                  <li class="list-group-item">Mahasiswa Pengunggah Kegiatan BEM IKOM: <br>
                    Nama: <?php echo e($siswa->nama); ?> <br>
                    NIM: <?php echo e($siswa->nim); ?>

                  </li>
                <?php elseif($kegiatan->Status == 'Senat'): ?>
                  <li class="list-group-item">Mahasiswa Pengunggah Kegiatan Senat IKOM: <br>
                    Nama: <?php echo e($siswa->nama); ?> <br>
                    NIM: <?php echo e($siswa->nim); ?>

                  </li>
                <?php elseif($kegiatan->Status == 'HMPTI'): ?>
                  <li class="list-group-item"> Mahasiswa Penggungah Kegiatan HMPTI IKOM: <br>
                    Nama: <?php echo e($siswa->nama); ?> <br>
                    NIM: <?php echo e($siswa->nim); ?>

                  </li>
                <?php else: ?>
                  <li class="list-group-item">Mahasiswa: <?php echo e($siswa->nama); ?></li>
                  <li class="list-group-item">NIM: <?php echo e($siswa->nim); ?></li>
                <?php endif; ?>
                  <li class="list-group-item">Tanggal: <?php echo e($kegiatan->Tanggal); ?></li>
                <?php if($kegiatan->Jenis_Bukti == 'Proposal'): ?>
                  <li class="list-group-item">Bukti Proposal: <?php echo e($kegiatan->Bukti); ?></li>  
                <?php elseif($kegiatan->Jenis_Bukti == 'LPJ'): ?>
                  <li class="list-group-item">LPJ: <?php echo e($kegiatan->Bukti); ?></li>  
                <?php else: ?>
                  <li class="list-group-item">Bukti: <?php echo e($kegiatan->Bukti); ?></li>                  
                <?php endif; ?>
                <?php if($kegiatan->Jenis_Bukti == 'SK' || $kegiatan->Jenis_Bukti == 'LPJ'): ?>
                  <li class="list-group-item">Foto: <?php echo e($kegiatan->Foto); ?></li>
                <?php endif; ?>
              </ul>

              <hr>

              <div class="well">
                <?php echo e($kegiatan->Deskripsi); ?>

              </div>

              <hr>

              <ul class="list-group">
                <li class="list-group-item">Status: <?php echo e($kegiatan->Kevalidan); ?></li>
              </ul>

              
              <?php if($peran_id == 8 || $peran_id == 9 || $peran_id == 10): ?>
                <?php if($kegiatan->Kevalidan == 'Menunggu validasi'): ?>
                  <table width = "200" align = "center">
                    <td>
                      <?php echo Form::open(['action' => ['KegiatanController@updateValidasi', $kegiatan->id], 'method' => 'POST']); ?>

                        <?php echo e(Form::hidden('Kevalidan', 'Valid')); ?>

                        <?php echo e(Form::hidden('_method', 'PATCH')); ?>

                        <?php echo e(Form::bsSubmit('Validasi', ['class' => 'btn btn-primary'])); ?>

                      <?php echo Form::close(); ?>

                    </td>
                    <td>
                      <?php echo Form::open(['action' => ['KegiatanController@updateValidasi', $kegiatan->id], 'method' => 'POST']); ?>

                        <?php echo e(Form::hidden('Kevalidan', 'Invalid')); ?>

                        <?php echo e(Form::hidden('_method', 'PATCH')); ?>  
                        <?php echo e(Form::bsSubmit('Invalidasi', ['class' => 'btn btn-danger'])); ?>

                      <?php echo Form::close(); ?>

                    </td>
                  </table>
                  
                <?php endif; ?>
              <?php endif; ?>
                
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>