<?php $__env->startSection('sidebar'); ?>
<?php echo $__env->yieldSection(); ?>