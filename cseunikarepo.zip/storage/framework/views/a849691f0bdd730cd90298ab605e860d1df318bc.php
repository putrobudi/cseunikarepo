<?php $__env->startSection('content'); ?>

<div class="row">
    <div class="col-md-8 col-md-offset-2">
        <div class="panel panel-default">
            <div class="panel-heading"><?php echo e($kegiatan->Judul); ?> <a href="/dashboard" class="pull-right btn btn-default btn-xs">Kembali</a></div>

            <div class="panel-body">
              <ul class="list-group">
                <li class="list-group-item">Mahasiswa: <?php echo e($siswa->nama); ?></li>
                <li class="list-group-item">NIM: <?php echo e($siswa->nim); ?></li>
                <li class="list-group-item">Tanggal: <?php echo e($kegiatan->Tanggal); ?></li>
                <li class="list-group-item">Bukti: <?php echo e($kegiatan->Bukti); ?></li>
                <li class="list-group-item">Foto: <?php echo e($kegiatan->Foto); ?></li>
              </ul>

              <hr>

              <div class="well">
                <?php echo e($kegiatan->Deskripsi); ?>

              </div>

              <hr>

              <ul class="list-group">
                <li class="list-group-item">Status: <?php echo e($kegiatan->Kevalidan); ?></li>
              </ul>

              <?php if($peran_id == 8 || $peran_id == 9 || $peran_id == 10): ?>
                <?php if($kegiatan->Kevalidan == 'Menunggu validasi'): ?>
                  <?php echo Form::open(['action' => ['KegiatanController@updateValidasi', $kegiatan->id], 'method' => 'POST']); ?>

                        <?php echo e(Form::bsSubmit('Validasi', ['class' => 'btn btn-primary'])); ?>

                  <?php echo Form::close(); ?>

                <?php endif; ?>
              <?php endif; ?>
                
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>