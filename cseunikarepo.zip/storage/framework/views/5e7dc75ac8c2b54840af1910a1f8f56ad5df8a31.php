<?php $__env->startSection('content'); ?>

<div class="row">
    <div class="col-md-8 col-md-offset-2">
        <div class="panel panel-default">
            <div class="panel-heading">
                <?php if($kegiatan->Jenis_Bukti == 'Proposal' && $kegiatan->Kevalidan == 'Valid'): ?>
                    Upload LPJ Kegiatan "<?php echo e($kegiatan->Judul); ?>"
                <?php else: ?>
                    Edit Kegiatan
                <?php endif; ?>
                     
                <?php if($kegiatan->Status == 'HMPSSI'): ?>
                <a href="/hmpssi" class="pull-right btn btn-default btn-xs">Kembali</a>
                <?php elseif($kegiatan->Status == 'BEM'): ?>
                <a href="/bem" class="pull-right btn btn-default btn-xs">Kembali</a>
                <?php elseif($kegiatan->Status == 'Senat'): ?>
                <a href="/senat" class="pull-right btn btn-default btn-xs">Kembali</a>
                <?php elseif($kegiatan->Status == 'HMPTI'): ?>
                <a href="/hmpti" class="pull-right btn btn-default btn-xs">Kembali</a>
                <?php else: ?>
                <a href="/dashboard" class="pull-right btn btn-default btn-xs">Kembali</a>
                <?php endif; ?>
            </div>

            <div class="panel-body">
                <?php if($kegiatan->Jenis_Bukti == 'Proposal' && $kegiatan->Kevalidan == 'Valid'): ?>
                    <?php echo Form::open(['action' => ['KegiatanController@updateLPJ', $kegiatan->id], 'method' => 'POST']); ?>

                        
                        <?php echo e(Form::bsText('Bukti', '', ['placeholder' => 'Upload LPJ'])); ?>

                        <?php echo e(Form::bsText('Foto', '', ['placeholder' => 'Foto Aktivitas'])); ?>

                        <?php echo e(Form::hidden('_method', 'PATCH')); ?>

                        <?php echo e(Form::bsSubmit('Submit LPJ', ['class' => 'btn btn-primary'])); ?>

                    <?php echo Form::close(); ?>

                <?php else: ?>
                    <?php echo Form::open(['action' => ['KegiatanController@update', $kegiatan->id], 'method' => 'POST']); ?>

                    <?php echo e(Form::bsText('Judul', $kegiatan->Judul, ['placeholder' => 'Judul kegiatan'])); ?>

                    <?php echo e(Form::bsDate('Tanggal', $kegiatan->Tanggal, ['placeholder' => 'Tanggal kegiatan dilakukan'])); ?>

                    <?php echo e(Form::bsTextArea('Deskripsi', $kegiatan->Deskripsi, ['placeholder' => 'Tentang Kegiatan'])); ?>

                    <?php if($kegiatan->Jenis_Bukti == 'Proposal'): ?>
                        <?php echo e(Form::bsText('Bukti', $kegiatan->Bukti, ['placeholder' => 'Proposal'])); ?>    
                    <?php else: ?>
                        <?php echo e(Form::bsText('Bukti', $kegiatan->Bukti, ['placeholder' => 'Sertifikat, Surat Sah'])); ?>    
                    <?php endif; ?>
                    <?php if($kegiatan->Jenis_Bukti == 'SK'): ?>
                        <?php echo e(Form::bsText('Foto', $kegiatan->Foto, ['placeholder' => 'Foto Aktivitas'])); ?>

                    <?php endif; ?>
                    <?php echo e(Form::hidden('_method', 'PUT')); ?>

                    <?php echo e(Form::bsSubmit('Submit', ['class' => 'btn btn-primary'])); ?>

                    <?php echo Form::close(); ?>

                <?php endif; ?>
                
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>