<?php $__env->startSection('content'); ?>

<div class="row">
    <div class="col-md-8 col-md-offset-2">
        <div class="panel panel-default">
            <?php if($peran_id == 8 || $peran_id == 9 || $peran_id == 10): ?>
            <div class="panel-heading">Dashboard</div>

            <div class="panel-body">
                <ul class="nav nav-tabs">
                    <li><a href="#">Kegiatan yang perlu divalidasi</a></li>
                    <li><a href="#">Kegiatan tervalidasi</a></li>
                    <li><a href="#">Kegiatan ditolak</a></li>
                </ul>
                



                <?php if(count($kegiatans)): ?>
                <ul class="list-group">
                    <?php $__currentLoopData = $kegiatans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kegiatan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li class="list-group-item"><a href="/kegiatans/<?php echo e($kegiatan->id); ?>"><?php echo e($kegiatan->Judul); ?></a></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
                <?php else: ?>
                <h3>Tidak ada kegiatan untuk diproses.</h3>
                <?php endif; ?>
                <?php else: ?>
                <div class="panel-heading">Dashboard <span class="pull-right"><a href="/kegiatans/create" class="btn btn-success btn-xs">Upload Kegiatan</a></span></div>
                <div class="panel-body">
                    <h3>Kegiatanmu</h3>

                    <?php if(count($kegiatans)): ?>
                    <table class="table table-striped">
                        <tr>
                            <th> Menunggu Validasi</th>
                            <th></th>
                            <th></th>
                        </tr>
                        <!-- loop through each kegiatan -->
                        <?php $__currentLoopData = $kegiatans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kegiatan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><a href="/kegiatans/<?php echo e($kegiatan->id); ?>"><?php echo e($kegiatan->Judul); ?></a></td>
                            <td><a class="pull-right btn btn-default" href="/kegiatans/<?php echo e($kegiatan->id); ?>/edit">Edit</a></td>
                            <td>
                                <?php echo Form::open(['action' => ['KegiatanController@destroy', $kegiatan->id], 'method' => 'POST', 'class' => 'pull-left', 'onsubmit' => 'return confirm("Are you sure?")']); ?>

                                <?php echo e(Form::hidden('_method', 'DELETE')); ?>

                                <?php echo e(Form::bsSubmit('Delete', ['class' => 'btn btn-danger'])); ?>

                                <?php echo Form::close(); ?>

                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </table>
                    <?php endif; ?>
                    <?php endif; ?>

                </div>
            </div>
        </div>
    </div>

    <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>