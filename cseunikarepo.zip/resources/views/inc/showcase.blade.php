<div class="jumbotron text-center">
    <div class="container">
        <h1>Welcome to Our Site</h1>
        <p class="lead">Welcome to our brand new Laravel powered website.
            This site uses Laravel version 5.4
        </p>
    </div>
</div>